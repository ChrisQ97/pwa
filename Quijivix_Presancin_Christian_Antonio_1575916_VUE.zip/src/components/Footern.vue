<template>
    <div>
  <b-card
    overlay
    img-src="https://static.wixstatic.com/media/587db1_859a83c49da2445fb90a5566bf1ca410.png"
    img-alt="Card Image"
    text-variant="white"
    title="Estimado Usuario">
    <b-card-text>
      Sitio en construccion.
    </b-card-text>
  </b-card>
</div>
</template>
<script>
export default {
    name: 'Footern'
}
</script>