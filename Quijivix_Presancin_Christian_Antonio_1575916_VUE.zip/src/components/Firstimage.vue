<template>
<div>

  
  <b-img src="https://www.caracteristicas.co/wp-content/uploads/2018/08/sistema-de-computadora-e1576255574952.jpg" fluid alt="Fluid image" width="300%"></b-img>
<h5>ollipop oat cake sweet roll gummies. Halvah cotton candy muffin tart biscuit sesame snaps cupcake cheesecake lollipop.</h5>
 

</div>
</template>
<script>
export default {
    name: 'Firstimage'
}
</script>
